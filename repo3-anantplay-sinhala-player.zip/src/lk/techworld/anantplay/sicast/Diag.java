package lk.techworld.anantplay.sicast;

import java.util.ArrayDeque;
import java.util.Deque;

/* The in-memory diagnostics ring every component logs to — the fix for the silent
 * death of the old companion: even when something goes wrong at 18:12 on a Xiaomi
 * phone, the what/when/why is in here, and MainActivity's Diagnostics screen shows
 * it with a Copy button (plus a file copy, so a crash still leaves a trace).
 *
 * Pure Java: the ring works on the bare JVM in the lab too; the Android app supplies
 * the file sink + the uncaught-exception hook via install(). */
public final class Diag {

    public interface Sink { void line(String s); }

    public static final int RING = 1200;

    private static final Object lock = new Object();
    private static final Deque<String> ring = new ArrayDeque<>();
    private static volatile Sink sink;
    private static long t0 = System.currentTimeMillis();

    private Diag() { }

    public static void install(Sink fileSink) { sink = fileSink; }

    public static void i(String tag, String msg) { add("I", tag, msg); }
    public static void w(String tag, String msg) { add("W", tag, msg); }
    public static void e(String tag, String msg) { add("E", tag, msg); }

    public static void crash(String where, Throwable t) {
        StringBuilder sb = new StringBuilder(512);
        sb.append("UNCAUGHT in ").append(where).append(": ").append(t);
        for (StackTraceElement el : t.getStackTrace()) {
            sb.append("\n    at ").append(el);
            if (sb.length() > 3000) { sb.append("\n    …"); break; }
        }
        add("E", "crash", sb.toString());
    }

    private static void add(String lvl, String tag, String msg) {
        long up = System.currentTimeMillis() - t0;
        String s = String.format(java.util.Locale.US, "%8d.%03d %s/%s: %s",
            up / 1000, up % 1000, lvl, tag, msg == null ? "" : msg.replace('\n', ' '));
        synchronized (lock) {
            if (ring.size() >= RING) ring.removeFirst();
            ring.addLast(s);
        }
        Sink sk = sink;
        if (sk != null) {
            try { sk.line(s); } catch (Throwable ignored) { }
        }
    }

    /** The ring as one text block (newest last) — the Copy Log button's payload. */
    public static String dump() {
        synchronized (lock) {
            StringBuilder sb = new StringBuilder(ring.size() * 96);
            for (String s : ring) sb.append(s).append('\n');
            return sb.toString();
        }
    }

    public static int size() { synchronized (lock) { return ring.size(); } }
}
