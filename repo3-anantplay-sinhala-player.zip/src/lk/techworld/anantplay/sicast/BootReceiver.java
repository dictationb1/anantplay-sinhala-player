package lk.techworld.anantplay.sicast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Arms the receiver after boot (MIUI delivers BOOT_COMPLETED only with the app's
 *  Autostart permission on — the setup checklist's step 2). */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (i == null || !Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) return;
        Diag.i("boot", "boot completed — arming");
        ReceiverService.arm(c, "boot");
    }
}
