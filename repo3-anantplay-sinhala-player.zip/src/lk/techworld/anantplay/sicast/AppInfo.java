package lk.techworld.anantplay.sicast;

/** Version + identity constants (no Gradle BuildConfig — plain aapt2/javac/d8 build). */
final class AppInfo {
    static final String VERSION_NAME = "2.0.0";
    static final int VERSION_CODE = 20000;
    static final String NAME = "AnantPlay Sinhala Player";
    private AppInfo() { }
}
