package lk.techworld.anantplay.sicast;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

/* THE receiver — the ESET survival pattern applied to the cast bridge:
 *
 *  - a connectedDevice FOREGROUND SERVICE (exactly AnantPlay's own Cast$Keep type,
 *    Cast.java:209-222, proven on MIUI by their whole user base) that keeps the
 *    ReceiverServer and the mDNS announcement alive after the app is left;
 *  - an IMPORTANCE_MIN notification ("අ — ready for AnantPlay cast") with quick
 *    actions: Open, Self-test, Stop;
 *  - the Backend wiring: /play starts PlayActivity (waits for it like Cast.play's
 *    50 × 100 ms loop), /do drives the player on the main thread (Cast.onMain's
 *    FutureTask pattern) or the device volume, /status reads the player snapshot.
 *
 * NO AccessibilityService anywhere. If HyperOS ever kills this idle service, nothing
 * shows "Not working": the user reopens the app or taps the tile, and while a movie
 * is playing the app IS the foreground app — unkillable by powerkeeper policy. */
public class ReceiverService extends Service implements ReceiverServer.Backend {

    static final String ACTION_STOP = "lk.techworld.anantplay.sicast.STOP";
    static final String ACTION_TEST = "lk.techworld.anantplay.sicast.TEST";

    private static volatile ReceiverService running;
    private final Handler main = new Handler(Looper.getMainLooper());
    private ReceiverServer server;
    private NsdAnnouncer nsd;
    private volatile boolean nexusTakeover;   // bring our player over AnantPlay's Remote

    public static boolean isUp() { return running != null; }
    public static int port() { ReceiverService s = running; return s == null ? -1 : (s.server == null ? -1 : s.server.port()); }

    /** Best-effort arm from any entry point (app start, boot, tile). */
    static void arm(Context c, String why) {
        Diag.i("service", "arm (" + why + ") from " + c.getClass().getSimpleName());
        try {
            c.startForegroundService(new Intent(c, ReceiverService.class));
        } catch (Throwable t) {
            Diag.w("service", "arm failed (background FGS rules?): " + t);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = this;
        server = new ReceiverServer(this);
        if (!server.start()) {
            Diag.e("service", "could not bind any port — receiver NOT armed");
            stopSelf();
            return;
        }
        nsd = new NsdAnnouncer(this, server.port());
        nsd.start();
        startInForeground();
        Diag.i("service", "up on port " + server.port() + (nsd.isAnnounced() ? " (announced)" : " (announce pending)"));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(a)) {
            Diag.i("service", "stop by user");
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_TEST.equals(a)) {
            try {
                startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("runTest", true));
            } catch (Throwable t) {
                Diag.w("service", "test launch: " + t);
            }
        }
        // keep alive through task removal: the receiver must survive AnantPlay swipes
        return START_STICKY;
    }

    private void startInForeground() {
        Notification n;
        try {
            PendingIntent open = PendingIntent.getActivity(this, 1,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
            PendingIntent test = PendingIntent.getService(this, 2,
                new Intent(this, ReceiverService.class).setAction(ACTION_TEST), PendingIntent.FLAG_IMMUTABLE);
            PendingIntent stop = PendingIntent.getService(this, 3,
                new Intent(this, ReceiverService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = new Notification.Builder(this, App.CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_si)
                .setContentTitle(getString(R.string.notif_title))
                .setContentText(getString(R.string.notif_text))
                .setContentIntent(open)
                .setOngoing(true)
                .setShowWhen(false)
                .addAction(new Notification.Action.Builder(null, getString(R.string.notif_test), test).build())
                .addAction(new Notification.Action.Builder(null, getString(R.string.notif_stop), stop).build());
            if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
            n = b.build();
        } catch (Throwable t) {
            Diag.w("service", "notification: " + t);
            n = new Notification.Builder(this, App.CHANNEL).setSmallIcon(R.drawable.ic_stat_si).build();
        }
        try {
            if (Build.VERSION.SDK_INT >= 29)
                startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            else startForeground(1, n);
        } catch (Throwable t) {
            // The connectedDevice type is what AnantPlay itself uses; if a vendor build
            // refuses it, fall back to the untyped call (still a foreground service).
            Diag.w("service", "typed startForeground failed, falling back: " + t);
            try { startForeground(1, n); } catch (Throwable t2) { Diag.e("service", "startForeground: " + t2); }
        }
    }

    @Override
    public void onDestroy() {
        running = null;
        if (nsd != null) nsd.stop();
        if (server != null) server.stop();
        Diag.i("service", "down");
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        Diag.i("service", "task removed — staying up (receiver)");
    }

    // ---- ReceiverServer.Backend ----

    /** /play: open our player, wait for it (Cast.play's pattern, 5 s), answer. */
    @Override
    public String onPlay(Map<String, Object> body, String sourceAddr) {
        String url = MiniJson.str(body, "url");
        String title = MiniJson.str(body, "title");
        Diag.i("play", "from " + sourceAddr + " url=" + url + " title=" + title);
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://")
            || url.startsWith("file://") || url.startsWith("content://")))
            return ReceiverServer.whyJson("bad link");   // Cast.play's own rule (Cast.java:144-145)
        if (url.startsWith("file://") && !PlayActivity.canReadSharedMedia(this)) {
            Diag.w("play", "file cast without media permission");
            PlayActivity.notifyNeedsMedia(this, title);
            return ReceiverServer.whyJson("blocked");
        }

        Intent i = new Intent(this, PlayActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("castJson", MiniJson.write(body));
        boolean overlay = Settings.canDrawOverlays(this);
        try {
            startActivity(i);
        } catch (Throwable t) {
            Diag.e("play", "startActivity: " + t);
            return ReceiverServer.whyJson(overlay ? "did not open" : "blocked");
        }
        for (int n = 0; n < 50; n++) {           // Cast.play's wait loop (Cast.java:171-176)
            try { Thread.sleep(100); } catch (InterruptedException e) { break; }
            if (PlayActivity.current() != null) {
                Diag.i("play", "player opened" + (overlay ? "" : " (no overlay perm — it worked anyway)"));
                if (overlay) scheduleTakeover();  // hand the screen from AnantPlay's Remote to our player
                return ReceiverServer.okJson();
            }
        }
        Diag.e("play", "player did not open (" + (overlay ? "?" : "no overlay permission → blocked") + ")");
        return ReceiverServer.whyJson(overlay ? "did not open" : "blocked");
    }

    /** After a successful cast AnantPlay opens its Remote on top; ~0.8 s later we bring
     *  our player back to the front (the user's intent was to WATCH here). The Remote
     *  keeps working — Cast.Remote polls only while resumed, and on our finish it
     *  sees {"idle":true} and hands the position back to AnantPlay's own player. */
    private void scheduleTakeover() {
        main.postDelayed(() -> {
            try {
                PlayActivity p = PlayActivity.current();
                if (p == null) return;
                Diag.i("takeover", "bringing the Sinhala player to the front");
                startActivity(new Intent(ReceiverService.this, PlayActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            } catch (Throwable t) {
                Diag.w("takeover", "not allowed now: " + t + " — the user can tap the notification");
            }
        }, 800);
    }

    /** /do — the player actions on the main thread (Cast.onMain's FutureTask), volume direct. */
    @Override
    public String onAction(String action, long to) {
        if ("vol+".equals(action) || "vol-".equals(action)) {
            try {
                ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).adjustStreamVolume(AudioManager.STREAM_MUSIC,
                    "vol+".equals(action) ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
            } catch (Throwable t) {
                Diag.w("do", "volume: " + t);
            }
            return PlayActivity.statusSnapshot();
        }
        PlayActivity p = PlayActivity.current();
        if (p == null) return ReceiverServer.idleJson();
        try {
            FutureTask<String> f = new FutureTask<>(() -> p.castAction(action, to));
            main.post(f);
            return f.get(3, TimeUnit.SECONDS);
        } catch (Exception e) {
            Diag.w("do", action + ": " + e);
            return p.statusJson();
        }
    }

    /** /status — the never-blocking snapshot path. */
    @Override
    public String status() {
        return PlayActivity.statusSnapshot();
    }

    /** /info extras. */
    @Override
    public Map<String, Object> info() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("announced", nsd != null && nsd.isAnnounced());
        m.put("playerOpen", PlayActivity.current() != null);
        m.put("overlayPerm", Settings.canDrawOverlays(this));
        m.put("batteryUnrestricted", ((android.os.PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName()));
        m.put("wifi", NsdAnnouncer.wifiLanIp() != null);
        m.put("xiaomi", isXiaomi());
        return m;
    }

    static boolean isXiaomi() {
        String m = Build.MANUFACTURER;
        return m != null && (m.equalsIgnoreCase("xiaomi") || m.equalsIgnoreCase("redmi"));
    }
}
