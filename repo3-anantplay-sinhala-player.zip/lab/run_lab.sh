#!/bin/sh
# The verification lab: compiles the pure-Java engines (the exact classes the APK
# ships) and drives them like AnantPlay's own DlnaTest — no emulator needed.
set -e
cd "$(dirname "$0")/.."
mkdir -p lab/out

echo "── compile the pure engines + the lab"
javac -encoding UTF-8 -nowarn -d lab/out/classes \
  src/lk/techworld/anantplay/sicast/ReceiverServer.java \
  src/lk/techworld/anantplay/sicast/BridgeApi.java \
  src/lk/techworld/anantplay/sicast/Cue.java \
  src/lk/techworld/anantplay/sicast/MiniJson.java \
  src/lk/techworld/anantplay/sicast/SrtLoader.java \
  src/lk/techworld/anantplay/sicast/SubtitleStore.java \
  src/lk/techworld/anantplay/sicast/Diag.java \
  src/lk/techworld/anantplay/sicast/AppInfo.java \
  lab/ReceiverLab.java

echo "── run the cast-protocol lab"
java -cp lab/out/classes lk.techworld.anantplay.sicast.ReceiverLab 2>&1 | tee lab/out/lab.txt

echo "── live bridge E2E (best effort)"
javac -encoding UTF-8 -nowarn -cp lab/out/classes -d lab/out/classes lab/BridgeLab.java
java -cp lab/out/classes lk.techworld.anantplay.sicast.BridgeLab lab/out/bridge.txt | tee lab/out/bridge-run.txt || echo "(bridge unreachable — recorded as SKIP)"
echo "done: lab/out/"
