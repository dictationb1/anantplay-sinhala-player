package lk.techworld.anantplay.sicast;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.pm.PackageInstaller;
import java.io.OutputStream;

/* v2.4.0 — THE BUILT-IN GITHUB SELF-UPDATER (zero external dependencies).
 *
 * THE HONEST ANDROID 16 SECURITY MODEL (non-root):
 *   Silent zero-tap APK installation is BLOCKED by the OS — PackageInstaller
 *   always shows the 1-tap system "Update" confirmation. That is by design and
 *   no app can (or should) bypass it. What we CAN do — mirroring official
 *   AnantPlay's own update flow — is everything up to that single tap:
 *     1. CHECK:   GET https://api.github.com/repos/dictationb1/anantplay-sinhala-player/releases/latest
 *                 automatically on every app launch (rate-limited to 15 min) and
 *                 every 6 h via JobScheduler (persisted, survives reboots).
 *     2. COMPARE: release versionName vs AppInfo.VERSION_NAME (UpdateChecker.isNewer).
 *     3. DOWNLOAD the single .apk asset from the SAME release, streaming.
 *     4. VERIFY:  SHA-256 of the download against SHA256SUMS.txt from the same
 *                 release — a corrupted or tampered APK is REFUSED and deleted.
 *     5. INSTALL: android.content.PackageInstaller.Session → the system's 1-tap
 *                 "Update" prompt → in-place update, SAME permanent keystore as
 *                 the GitHub Release build → zero uninstall, data preserved.
 *   Obtainium compatibility is unaffected: Obtainium reads the same GitHub
 *   Releases independently; both paths install over each other (same key).
 *
 * The pure-Java core (release parsing, hash verification) is SelfUpdateCore —
 * the lab drives it on a bare JVM against a local mock GitHub server. */
public final class SelfUpdater {

    static final String REPO = "dictationb1/anantplay-sinhala-player";
    static final String API_LATEST = "https://api.github.com/repos/" + REPO + "/releases/latest";
    /** Launch check rate limit (ms). */
    static final long MIN_CHECK_INTERVAL_MS = 15 * 60 * 1000L;
    static final int JOB_ID = 20400;

    private SelfUpdater() { }

    // ── the launch check (rate-limited) ────────────────────────────────────────

    /** Called from App.onCreate: fire the background check at most once per
     *  15 min. Non-blocking, never throws. */
    public static void checkOnLaunch(final Context c) {
        try {
            long last = c.getSharedPreferences("selfupdate", Context.MODE_PRIVATE).getLong("lastCheck", 0);
            if (System.currentTimeMillis() - last < MIN_CHECK_INTERVAL_MS) return;
            schedule(c, 0L);
        } catch (Throwable t) {
            Diag.w("selfupd", "launch check: " + t);
        }
    }

    /** One-shot ASAP job (network permitting). */
    public static void schedule(Context c, long delayMs) {
        try {
            JobScheduler js = c.getSystemService(JobScheduler.class);
            if (js == null) return;
            JobInfo.Builder b = new JobInfo.Builder(JOB_ID,
                new ComponentName(c, CheckJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setMinimumLatency(delayMs)
                .setOverrideDeadline(delayMs + 30 * 60 * 1000L);
            js.schedule(b.build());
            c.getSharedPreferences("selfupdate", Context.MODE_PRIVATE).edit()
                .putLong("lastCheck", System.currentTimeMillis()).apply();
        } catch (Throwable t) {
            Diag.w("selfupd", "schedule: " + t);
        }
    }

    /** The standing 6-hour periodic schedule (persisted). */
    public static void schedulePeriodic(Context c) {
        try {
            JobScheduler js = c.getSystemService(JobScheduler.class);
            if (js == null) return;
            JobInfo info = new JobInfo.Builder(JOB_ID + 1, new ComponentName(c, CheckJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(6 * 60 * 60 * 1000L)
                .setPersisted(true)
                .build();
            js.schedule(info);
        } catch (Throwable t) {
            Diag.w("selfupd", "periodic schedule: " + t);
        }
    }

    // ── the flow: check + download + verify + install ──────────────────────────

    /** One update attempt. Returns a human-readable result (also logged). */
    public static String checkAndMaybeInstall(Context c) {
        try {
            SelfUpdateCore.Release rel = SelfUpdateCore.fetchRelease(API_LATEST);
            if (rel == null) return "no release";
            if (!UpdateChecker.isNewer(rel.version, AppInfo.VERSION_NAME)) {
                Diag.i("selfupd", "up to date (" + AppInfo.VERSION_NAME + "; latest " + rel.version + ")");
                return "up-to-date";
            }
            Diag.i("selfupd", "new release " + rel.version + " > " + AppInfo.VERSION_NAME + " — downloading");
            App.notifyUpdate(c, rel.version);          // the banner: "ඩවුන්ලෝඩ් වෙමින්…"
            byte[] apk = SelfUpdateCore.download(rel.apkUrl);
            String sha = SelfUpdateCore.sha256(apk);
            if (rel.sha256Expected != null && !rel.sha256Expected.equalsIgnoreCase(sha)) {
                Diag.e("selfupd", "SHA-256 MISMATCH — refusing to install (downloaded " + sha
                    + ", expected " + rel.sha256Expected + ")");
                App.notifyUpdateFailed(c, rel.version);
                return "sha-mismatch";
            }
            if (rel.sha256Expected == null) {
                // a release without a SHA256SUMS line for the apk: refuse (security)
                Diag.w("selfupd", "no SHA-256 line for " + SelfUpdateCore.apkFileName(rel.apkUrl) + " — refusing");
                App.notifyUpdateFailed(c, rel.version);
                return "no-sha";
            }
            App.notifyUpdateReady(c, rel.version);     // verified — install prompt next
            install(c, apk);
            return "installing " + rel.version;
        } catch (Throwable t) {
            Diag.w("selfupd", "check: " + t);
            return "offline";
        }
    }

    // ── the install (Android side) ─────────────────────────────────────────────

    /** Stream the verified APK into a PackageInstaller.Session → the system's
     *  1-tap "Update" prompt appears immediately. Same-signature updates install
     *  in place: no uninstall, all data (subs cache, prefs) preserved. */
    static void install(Context c, byte[] apk) throws Exception {
        PackageInstaller pi = c.getPackageManager().getPackageInstaller();
        PackageInstaller.Session session = null;
        int sid = -1;
        try {
            sid = pi.createSession(new PackageInstaller.SessionParams(
                PackageInstaller.SessionParams.MODE_FULL_INSTALL));
            session = pi.openSession(sid);
            OutputStream out = session.openWrite("update", 0, -1);
            out.write(apk);
            out.flush();
            session.fsync(out);
            out.close();
            Intent ok = new Intent(c, InstallResultReceiver.class);
            PendingIntent piOk = PendingIntent.getBroadcast(c, sid, ok,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
            session.commit(piOk.getIntentSender());
            Diag.i("selfupd", "install session " + sid + " committed (" + apk.length + " B) — waiting for the 1-tap prompt");
        } catch (Throwable t) {
            if (session != null) try { session.abandon(); } catch (Throwable ignored) { }
            throw t;
        }
    }

    /** Receives the install result broadcast (STATUS_PENDING_USER_ACTION → the
     *  system dialog was shown; we forward the user's confirm intent). */
    public static final class InstallResultReceiver extends android.content.BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) {
            try {
                int status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
                if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                    Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
                    if (confirm != null) {
                        confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        c.startActivity(confirm);   // the 1-tap "Update" dialog
                        Diag.i("selfupd", "user-action prompt shown");
                    }
                } else if (status == PackageInstaller.STATUS_SUCCESS) {
                    Diag.i("selfupd", "installed ✓");
                    App.notifyUpdateDone(c);
                } else {
                    Diag.w("selfupd", "install status " + status + ": "
                        + i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE));
                }
            } catch (Throwable t) {
                Diag.w("selfupd", "install result: " + t);
            }
        }
    }

    /** The JobScheduler entry: check + (when needed) download/verify/install. */
    public static final class CheckJob extends JobService {
        @Override public boolean onStartJob(final JobParameters params) {
            new Thread(() -> {
                try { checkAndMaybeInstall(getApplicationContext()); } catch (Throwable ignored) { }
                jobFinished(params, false);
                schedulePeriodic(getApplicationContext());   // keep the 6 h schedule alive
            }, "si-selfupd").start();
            return true;
        }
        @Override public boolean onStopJob(JobParameters params) { return true; }   // retry later
    }
}
