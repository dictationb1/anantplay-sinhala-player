// AnantPlay Sinhala Player v3.4.6.c — the Home shell: Mornye collapsing large
// title with the top-right Settings + Check-Update glass buttons, the instant
// in-app auto-update glass card (live 0→100% + 1-tap Update Now), the receiver
// hero glass card (Start/Stop flips status + the native ReceiverService
// immediately), 4 REAL quick-action tiles (every one does something visible),
// and Continue Watching (progress, exact resume timestamp, 1-tap resume,
// delete row, clear all).
//
// v3.4.6.c — THE "FAKE UI" FIX, per tile:
//   · AnantPlay → launches the official app OR the in-app installer sheet
//   · Browser   → switches the SHELL to the live Browser tab (no PlayActivity)
//   · Play URL  → the Mornye glass URL sheet (Paste + Play) → PlayerScreen
//   · Test      → the MORNYE CINEMA PLAYER (player_screen.dart over the real
//                 Media3TextureBridge) with the Mux HLS test + Sinhala demo
import 'dart:async' show StreamSubscription;

import 'package:flutter/services.dart' show Clipboard;
import 'package:material_ui/material_ui.dart';

import 'package:anantplay_ui/mornye_ui/widgets/animation_utils.dart';

import 'app_state.dart';
import 'bridge.dart';
import 'package:anantplay_ui/main.dart';
import 'settings_mirror.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    final state = AppState.of(context);
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: scheme.surface,
      body: SafeArea(
        bottom: false,
        child: CustomScrollView(
          slivers: [
            SliverAppBar.large(
              title: const Text('AnantPlay Player'),
              backgroundColor: scheme.scrim.withValues(alpha: 0.2),
              surfaceTintColor: Colors.transparent,
              expandedHeight: 128,
              pinned: true,
              // v3.4.6.c — complaint #1/#2 fix: Settings is ALWAYS 1-tap
              // reachable from Home's own top bar, in ADDITION to the tab.
              actions: [
                IconButton(
                  tooltip: 'Check for update',
                  icon: const Icon(Icons.system_update_rounded),
                  onPressed: () => AnantPlay.instance.checkForUpdate(),
                ),
                IconButton(
                  tooltip: 'Settings',
                  icon: const Icon(Icons.settings_rounded),
                  onPressed: () =>
                      ShellRootState.of(context).selectTab(2),
                ),
                const SizedBox(width: 4),
              ],
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // v3.4.6.b — the Mornye entry reveal (upstream Home's
                    // StaggeredListItem): 0.2 s spatial spring per section,
                    // 40 ms stagger. animate:false is never needed here — the
                    // widget itself skips on scrolled/reduced-motion.
                    StaggeredListItem(
                      index: 0,
                      duration: const Duration(milliseconds: 250),
                      staggerDelay: const Duration(milliseconds: 40),
                      child: _UpdateCard(event: state.updaterEvent),
                    ),
                    const SizedBox(height: 16),
                    StaggeredListItem(
                      index: 1,
                      child: _ReceiverHero(status: state.castStatus),
                    ),
                    const SizedBox(height: 16),
                    StaggeredListItem(
                      index: 2,
                      child: _QuickStartCard(settings: state.settings),
                    ),
                    StaggeredListItem(index: 3, child: const _QuickActions()),
                    const SizedBox(height: 20),
                    StaggeredListItem(
                      index: 4,
                      child: _ContinueWatching(history: state.history),
                    ),
                    const SizedBox(height: 28),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── the receiver hero glass card ─────────────────────────────────────────────

class _ReceiverHero extends StatelessWidget {
  const _ReceiverHero({required this.status});

  final CastStatus status;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final up = status.up;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHigh.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
            color: up
                ? scheme.primary.withValues(alpha: 0.55)
                : scheme.outlineVariant.withValues(alpha: 0.4),
            width: up ? 1.4 : 1),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 9,
                height: 9,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: up ? scheme.primary : scheme.outline,
                  boxShadow: up
                      ? [BoxShadow(
                          color: scheme.primary.withValues(alpha: 0.5),
                          blurRadius: 8)]
                      : null,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  // v3.4.6.c — the user-visible status flip the hero owes:
                  // the label states exactly what the receiver is doing.
                  up ? 'Active · Ready for Cast' : 'Stopped',
                  style: TextStyle(
                    color: scheme.onSurface,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              Text(
                up && status.port > 0 ? ':${status.port}' : '',
                style: TextStyle(
                    color: scheme.onSurfaceVariant, fontSize: 13),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            up
                ? (status.mdns
                    ? 'Announced on the LAN — cast from AnantPlay.'
                    : 'Cast server up (announcing…).')
                : 'Start it to accept casts from the official app.',
            style: TextStyle(
                color: scheme.onSurfaceVariant, fontSize: 12.5, height: 1.4),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  // v3.4.6.c — REAL toggle: arm/stop the native ReceiverService
                  // and flip the card (the status stream pushes the change).
                  onPressed: () => up
                      ? AnantPlay.instance.stopReceiver()
                      : AnantPlay.instance.armReceiver(),
                  style: FilledButton.styleFrom(
                    backgroundColor: up
                        ? scheme.surfaceContainerHighest
                        : scheme.primary,
                    foregroundColor:
                        up ? scheme.onSurface : scheme.onPrimary,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(13)),
                  ),
                  icon: Icon(
                      up ? Icons.stop_rounded : Icons.play_arrow_rounded,
                      size: 18),
                  label: Text(
                      up
                          ? 'Stop Receiver'
                          : 'Start Receiver',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── the auto-update glass card ───────────────────────────────────────────────

class _UpdateCard extends StatelessWidget {
  const _UpdateCard({required this.event});

  final UpdaterEvent? event;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final e = event;
    if (e == null) return const SizedBox.shrink();
    final isProgress = e.type == 'progress';
    final isPending = e.type == 'pending' || e.type == 'available';
    if (!isProgress && !isPending) return const SizedBox.shrink();
    final pct = int.tryParse(e.value) ?? 0;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: scheme.primaryContainer.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(16),
        border:
            Border.all(color: scheme.primary.withValues(alpha: 0.4)),
      ),
      child: Row(
        children: [
          Icon(Icons.system_update_rounded,
              color: scheme.primary, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: isProgress
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Downloading update — $pct%…',
                          style: TextStyle(
                              color: scheme.onSurface, fontSize: 13.5)),
                      const SizedBox(height: 6),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(3),
                        child: LinearProgressIndicator(
                          // v3.4.6.c — the live 0→100% bar (the old banner
                          // printed the version string into the percent).
                          value: pct.clamp(0, 100) / 100.0,
                          minHeight: 4,
                          backgroundColor:
                              scheme.onSurface.withValues(alpha: 0.1),
                          color: scheme.primary,
                        ),
                      ),
                    ],
                  )
                : Text(
                    e.type == 'pending'
                        ? 'Update ready: v${e.value} — tap to install'
                        : 'Update available: v${e.value}',
                    style: TextStyle(
                        color: scheme.onSurface, fontSize: 13.5),
                  ),
          ),
          if (!isProgress)
            TextButton(
              onPressed: () => AnantPlay.instance.installPendingUpdate(),
              child: const Text('Update Now'),
            ),
        ],
      ),
    );
  }
}

// ── the one-time quick-start card (K_QUICKSTART_DONE) ───────────────────────

/// Mornye Glass, one glance: what to do first, and how to get back to the
/// wizard later. It retires itself the moment the user says it has been read —
/// the pref is a normal backed-up key, so it survives export/restore.
class _QuickStartCard extends StatelessWidget {
  const _QuickStartCard({required this.settings});

  final SettingsMirror settings;

  @override
  Widget build(BuildContext context) {
    if (settings.quickstartDone) return const SizedBox(height: 16);
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerHigh.withValues(alpha: 0.4),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color:
                  theme.colorScheme.outlineVariant.withValues(alpha: 0.4)),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
          child: Row(
            children: [
              Icon(Icons.tips_and_updates_rounded,
                  size: 22, color: theme.colorScheme.primary),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'First time? Cast from AnantPlay, or open the Browser tab to '
                  'watch with Sinhala subtitles.',
                  style: TextStyle(
                      fontSize: 13,
                      height: 1.35,
                      color: theme.colorScheme.onSurface),
                ),
              ),
              TextButton(
                onPressed: () => AppState.of(context).scope.dismissQuickstart(),
                child: const Text('Got it'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── quick actions ───────────────────────────────────────────────────────────

class _QuickActions extends StatelessWidget {
  const _QuickActions();

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 1.62,
      children: [
        _ActionTile(
          icon: Icons.cast_rounded,
          title: 'AnantPlay',
          subtitle: 'Open the official app',
          // v3.4.6.c — the official app, OR (not installed) the in-app
          // AnantPlayInstaller sheet — never a silent no-op.
          onTap: () async {
            final installed = await AnantPlay.instance.officialInstalled();
            if (!context.mounted) return;
            if (installed) {
              await AnantPlay.instance.openOfficialApp();
            } else {
              showInstallerSheet(context);
            }
          },
        ),
        _ActionTile(
          icon: Icons.public_rounded,
          title: 'Browser',
          subtitle: 'Cinema WebView browser',
          // v3.4.6.c — complaint #1 fix: this tile switches the SHELL to the
          // live Browser tab (was: an openWebTab no-op that opened nothing).
          onTap: () => ShellRootState.of(context).openBrowserTab(),
        ),
        _ActionTile(
          icon: Icons.link_rounded,
          title: 'Play URL',
          subtitle: 'Stream any link here',
          onTap: () => _openUrlSheet(context),
        ),
        _ActionTile(
          icon: Icons.science_rounded,
          title: 'Test Player',
          subtitle: 'Mornye cinema demo',
          // v3.4.6.c — complaint #3 fix: the MORNYE CINEMA PLAYER in the
          // shell (was: the raw Java PlayActivity).
          onTap: () => ShellRootState.of(context).pushPlayer(
                const PlayRequest(
                  url: '',
                  test: true,
                ),
              ),
        ),
      ],
    );
  }

  /// The Mornye Liquid-Glass URL sheet: Paste (clipboard) + Play. Empty input
  /// is refused with a hint — the button can never be a dead tap.
  static void _openUrlSheet(BuildContext context) {
    final controller = TextEditingController();
    final scheme = Theme.of(context).colorScheme;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: scheme.surfaceContainerHigh,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
      isScrollControlled: true,
      builder: (sheetContext) {
        return Padding(
          padding: EdgeInsets.fromLTRB(
              20, 20, 20, 20 + MediaQuery.viewInsetsOf(sheetContext).bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Play a URL',
                  style: TextStyle(
                      color: scheme.onSurface,
                      fontSize: 18,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text('Any HLS / DASH / MP4 link — played in the Mornye Cinema Player.',
                  style: TextStyle(
                      color: scheme.onSurfaceVariant, fontSize: 12.5)),
              const SizedBox(height: 16),
              TextField(
                controller: controller,
                autofocus: true,
                decoration: InputDecoration(
                  hintText: 'https://example.com/stream.m3u8',
                  prefixIcon: const Icon(Icons.link_rounded),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  OutlinedButton.icon(
                    icon: const Icon(Icons.content_paste_rounded, size: 18),
                    label: const Text('Paste'),
                    onPressed: () async {
                      final data = await Clipboard.getData('text/plain');
                      final text = data?.text?.trim() ?? '';
                      if (text.isNotEmpty) controller.text = text;
                    },
                  ),
                  const Spacer(),
                  FilledButton.icon(
                    icon: const Icon(Icons.play_arrow_rounded, size: 20),
                    label: const Text('Play'),
                    onPressed: () {
                      final url = controller.text.trim();
                      if (!url.startsWith('http')) {
                        ScaffoldMessenger.of(sheetContext).showSnackBar(
                            const SnackBar(
                                content: Text(
                                    'Paste a http(s) link first')));
                        return;
                      }
                      Navigator.pop(sheetContext);
                      ShellRootState.of(context).pushPlayer(PlayRequest(
                          url: url, title: url));
                    },
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

/// The in-app AnantPlay installer sheet (official app not installed): the
/// same live resolve → percent → PackageInstaller pipeline onboarding uses.
void showInstallerSheet(BuildContext context) {
  final scheme = Theme.of(context).colorScheme;
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: scheme.surfaceContainerHigh,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
    ),
    builder: (sheetContext) {
      return _InstallerSheet(scheme: scheme);
    },
  );
}

class _InstallerSheet extends StatefulWidget {
  const _InstallerSheet({required this.scheme});

  final ColorScheme scheme;

  @override
  State<_InstallerSheet> createState() => _InstallerSheetState();
}

class _InstallerSheetState extends State<_InstallerSheet> {
  int _percent = 0;
  String _state = '';
  bool _running = false;
  StreamSubscription<InstallEvent>? _installSub;

  @override
  void initState() {
    super.initState();
    // v3.4.6.f — the ONE bridge hub subscription is cancelled on dispose:
    // every previously opened sheet leaked a listener forever (each new
    // sheet stacked ANOTHER one). The hub makes them harmless to the native
    // side; this makes them harmless to memory as well.
    _installSub = AnantPlay.instance.installEvents().listen((e) {
      if (!mounted) return;
      setState(() {
        if (e.type == 'installProgress') {
          _running = true;
          _percent = e.percent;
        } else {
          _state = e.extra.isEmpty ? e.value : '${e.value} · ${e.extra}';
        }
      });
    });
  }

  @override
  void dispose() {
    _installSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = widget.scheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Install official AnantPlay',
              style: TextStyle(
                  color: scheme.onSurface,
                  fontSize: 18,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text(
              'AnantPlay is the casting remote — install it to cast movies here.',
              style:
                  TextStyle(color: scheme.onSurfaceVariant, fontSize: 12.5)),
          const SizedBox(height: 16),
          if (_running || _percent > 0) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: LinearProgressIndicator(
                value: _percent.clamp(0, 100) / 100.0,
                minHeight: 5,
                backgroundColor: scheme.onSurface.withValues(alpha: 0.1),
                color: scheme.primary,
              ),
            ),
            const SizedBox(height: 6),
            Text(_state.isEmpty ? '$_percent%' : _state,
                style: TextStyle(
                    color: scheme.onSurfaceVariant, fontSize: 12)),
            const SizedBox(height: 12),
          ] else
            FilledButton.icon(
              icon: const Icon(Icons.download_rounded, size: 20),
              label: const Text('Download & Install'),
              onPressed: () =>
                  AnantPlay.instance.installOfficialAnantPlay(),
            ),
        ],
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: scheme.surfaceContainerHigh.withValues(alpha: 0.35),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
                color: scheme.outlineVariant.withValues(alpha: 0.4)),
          ),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: scheme.primaryContainer.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: scheme.primary, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(title,
                        style: TextStyle(
                            color: scheme.onSurface,
                            fontSize: 14,
                            fontWeight: FontWeight.w600)),
                    const SizedBox(height: 2),
                    Text(subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: scheme.onSurfaceVariant,
                            fontSize: 11.5)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── continue watching ────────────────────────────────────────────────────────

class _ContinueWatching extends StatelessWidget {
  const _ContinueWatching({required this.history});

  final List<HistoryItem> history;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    if (history.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 18),
        child: Center(
          child: Text(
              'Nothing watched yet — cast or open a link to begin.',
              style: TextStyle(
                  color: scheme.onSurfaceVariant, fontSize: 13)),
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text('Continue watching',
                  style: TextStyle(
                      color: scheme.onSurface,
                      fontSize: 17,
                      fontWeight: FontWeight.w700)),
            ),
            TextButton(
              // v3.4.6.c — Clear all (each row also has its own delete).
              onPressed: () {
                // fire-and-forget per row, then one refresh — the scope
                // notifies the shell itself; no context use after await.
                for (final it in List<HistoryItem>.from(history)) {
                  AnantPlay.instance.removeHistory(it.key);
                }
                AppState.of(context).scope.refresh();
              },
              child: const Text('Clear all'),
            ),
          ],
        ),
        const SizedBox(height: 10),
        for (final it in history.take(6))
          _HistoryRow(item: it),
      ],
    );
  }
}

class _HistoryRow extends StatelessWidget {
  const _HistoryRow({required this.item});

  final HistoryItem item;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final resumable = item.resumable;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: scheme.surfaceContainerHigh.withValues(alpha: 0.25),
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          // v3.4.6.c — 1-tap resume IN the Mornye Cinema Player, at the
          // saved position (the bridge seeks on open), with the timestamp
          // shown right on the row.
          onTap: () => ShellRootState.of(context).pushPlayer(PlayRequest(
                url: item.url,
                title: item.title,
                resumeMs: item.pos.round(),
              )),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                          item.title.isEmpty ? item.url : item.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: scheme.onSurface,
                              fontSize: 13.5,
                              fontWeight: FontWeight.w500)),
                      const SizedBox(height: 6),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(3),
                        child: LinearProgressIndicator(
                          value: item.percent / 100.0,
                          minHeight: 3,
                          backgroundColor:
                              scheme.onSurface.withValues(alpha: 0.1),
                          color: scheme.primary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item.dur > 0
                            ? '${_clock(item.pos)} / ${_clock(item.dur)}'
                            : _clock(item.pos),
                        style: TextStyle(
                            color: scheme.onSurfaceVariant, fontSize: 11),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                if (resumable)
                  Icon(Icons.play_arrow_rounded,
                      color: scheme.primary, size: 20)
                else
                  Icon(Icons.replay_rounded,
                      color: scheme.onSurfaceVariant, size: 16),
                // v3.4.6.c — per-row delete (Dismissible-style tap target).
                IconButton(
                  tooltip: 'Remove',
                  visualDensity: VisualDensity.compact,
                  icon: Icon(Icons.close_rounded,
                      size: 16, color: scheme.onSurfaceVariant),
                  onPressed: () {
                    AnantPlay.instance.removeHistory(item.key);
                    AppState.of(context).scope.refresh();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  static String _clock(double ms) {
    final s = (ms / 1000).round();
    final h = s ~/ 3600;
    final m = (s % 3600) ~/ 60;
    final sec = s % 60;
    return h > 0
        ? '$h:${m.toString().padLeft(2, '0')}:${sec.toString().padLeft(2, '0')}'
        : '${m.toString().padLeft(2, '0')}:${sec.toString().padLeft(2, '0')}';
  }
}
